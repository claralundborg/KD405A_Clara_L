package se.mah.c3larra;

public class Constants {
	
	public static final int MIN_LETTERS = 3;
	
}
